namespace Assets.Scripts.Util 
{
    public enum CardinalDirection { North, South, East, West }
}