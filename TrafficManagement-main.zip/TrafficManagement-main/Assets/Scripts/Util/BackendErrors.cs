namespace Assset.Scripts.Util
{
    enum BackendErrors 
    {
        InvalidInputException,
        CalculationException,
        UnknownException,
        UnimplementedException,
    }
}
