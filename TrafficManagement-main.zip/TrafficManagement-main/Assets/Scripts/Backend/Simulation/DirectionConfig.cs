namespace Assets.Scripts.Backend.Simulation
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using Assets.Scripts.Util;
    public class DirectionConfig
    {


        public DirectionDetails boundDir { get; set; }  // e.g., "Northbound", "Southbound"
        

        //change 
        public Road road {get; set;}
         
        private CardinalDirection _LeftTurnDir;

        public double TrafficPriority {get; set;}

        public CardinalDirection LeftTurnDir {
            get{return _LeftTurnDir;}
            set{
                switch(Name){
                    case North :
                        _LeftTurnDir = West;
                        break;
                    case East :
                        _LeftTurnDir = North;
                        break;
                    case West :
                        _LeftTurnDir = South;
                        break;
                    default : 
                        _LeftTurnDir = East;
                        break;
                }
            }
        }
    }



    // public override bool Equals(object obj)
    // {
    //     if (obj is DirectionConfig other)
    //     {
    //         return this.Name == other.Name; 
    //     }
    //     return false;
    // }

    // public override int GetHashCode()
    // {
    //     return Name.GetHashCode(); 
    // }

}
