namespace Assets.Scripts.Backend.Simulation 
{
    using System.Collections.Generic;
    using System;
    using System.Linq;
    
    using Assets.Scripts.Backend.Engine;
    using Assets.Scripts.Util;
    using Assets.Scripts.Backend.Queuing;
    public class Simulation {

        
        
        private DirectionConfig[] Directions = new DirectionConfig[4];
        protected Engine Engine;

        //Traffic Light data
        private int currPhaseIndex = 0;
        private DateTime phaseEndTime;
        private bool phaseInitialised = false;

        //Random
        private Random rnum = new Random();
        

        public Simulation(Engine engine, InputParameters dirInfo){


            if (engine == null)
            {
                throw new ArgumentNullException(nameof(engine), "Engine cannot be null.");
            }

            this.Engine = engine;

            
            Directions = new DirectionConfig[]
            {
                new DirectionConfig
                {
                    boundDir = dirInfo.Northbound;
                    road = new Road(engine) 
                    {
                        numLanesInbound = dirInfo.Northbound.LaneCountInbound, 
                        numLanesOutbound = dirInfo.Northbound.LaneCountOutbound,
                        TrafficPriority = dirInfo.priority.FirstOrDefault(p => p.Item1 == CardinalDir.North).Item2
                    };
                },
                new DirectionConfig
                {
                    boundDir = dirInfo.Southbound;
                    road = new Road(engine) 
                    {
                        numLanesInbound = dirInfo.Southbound.LaneCountInbound, 
                        numLanesOutbound = dirInfo.Southbound.LaneCountOutbound
                        TrafficPriority = dirInfo.priority.FirstOrDefault(p => p.Item1 == CardinalDir.South).Item2
                    };
                },
                new DirectionConfig
                {
                    boundDir = dirInfo.Westbound;
                    road = new Road(engine) 
                    {
                        numLanesInbound = dirInfo.Westbound.LaneCountInbound, 
                        numLanesOutbound = dirInfo.Westbound.LaneCountOutbound
                        TrafficPriority = dirInfo.priority.FirstOrDefault(p => p.Item1 == CardinalDir.West).Item2
                    };
                },
                new DirectionConfig
                {
                    boundDir = dirInfo.Eastbound;
                    road = new Road(engine) 
                    {
                        numLanesInbound = dirInfo.Eastbound.LaneCountInbound, 
                        numLanesOutbound = dirInfo.Eastbound.LaneCountOutbound,
                        TrafficPriority = dirInfo.priority.FirstOrDefault(p => p.Item1 == CardinalDir.East).Item2
                    
                    };
                }    
            };
            

            
            

        }


    }

}