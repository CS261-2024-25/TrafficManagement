namespace Assets.Scripts.Backend.Simulation
{

    public class VehicleLane {

        public double currLaneLength {get; set;}
        public Queue<Vehicle> vehicleQueue = new Queue<Vehicle>();
        
    }
    public class Vehicle
    {
        public double VehicleLength {get; set;}
        public DateTime EntryTime { get; set; }
        public DateTime ExitTime { get; set; }
        public string ExitDir {get; set;}

        
    }
}
